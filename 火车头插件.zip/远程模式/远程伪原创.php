<?php
function translate($url,$text){
    $data = array("info"=>$text);
    $ch = curl_init();
	sleep(1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 4);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_USERAGENT, "HCT");
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $output = curl_exec($ch);
    curl_close($ch);
	return  $output;
}
function mbStrSplit ($string, $len=1030) {
  $start = 0;
  $strlen = mb_strlen($string);
  while ($strlen) {
    $array[] = mb_substr($string,$start,$len,"utf8");
    $string = mb_substr($string, $len, $strlen,"utf8");
    $strlen = mb_strlen($string);
  }
  return $array;
}

if($LabelArray['PageType']=="Save"){
	$url='你的api.php网址'; //测试地址http://daohang.bunian.cn/ai/999.php
	
	$str = preg_replace('/[\x80-\xff]{1,3}/', ' ', $LabelArray['内容'], -1); 
	$num = strlen($str);
	if($num>1030){
		$content=mbStrSplit($LabelArray['内容']);
		$info ='';
		foreach($content as $value){
			$info.=translate($url,$value);//文章内容
		}
	}else{
		$info =translate($url,$LabelArray['内容']);//文章内容
	}
	$LabelArray['内容']=$info;
}
echo serialize($LabelArray);